<?php
if (!defined('ABSPATH')) define('ABSPATH',  __DIR__. '/');

if (!defined('ABSPATH_SITE')) define('ABSPATH_SITE', ABSPATH . 'site/');

if (!defined('SERVERNAME')) define('SERVERNAME', 'sql308.infinityfree.com');
if (!defined('USERNAME')) define('USERNAME', 'if0_39478441');
if (!defined('PASSWORD')) define('PASSWORD', 'ECCSfmZRH0');
if (!defined('DBNAME')) define('DBNAME', 'ifo_39478441_godashop');

// SMTP (send mail)
if (!defined('SMTP_USERNAME')) define('SMTP_USERNAME', 'nguyenthuchanh2021@gmail.com');

if (!defined('SMTP_SECRET')) define('SMTP_SECRET', 'howrfxnasqiuybxy');

if (!defined('SMTP_HOST')) define('SMTP_HOST', 'smtp.gmail.com');

if (!defined('SHOP_OWNER')) define('SHOP_OWNER', 'nguyenhuulocla2006@gmail.com');

if (!defined('GOOGLE_RECAPTCHA_SITE')) define('GOOGLE_RECAPTCHA_SITE', '6Lcj07oUAAAAALAHcj_WdDa7Vykqzui3mSA5SIoe');

if (!defined('GOOGLE_RECAPTCHA_SECRET')) define('GOOGLE_RECAPTCHA_SECRET', '6Lcj07oUAAAAAKKbrzK72AzMqqVwxnsVTjlvx_0J');

if (!defined('JWT_KEY')) define('JWT_KEY', 'godashop_k67');
// define("GOOGLE_CLIENT_ID","467247032240-4k4stmd35nn@hhloqdvtg573qb6bo2pv.apps.googleuserconIcom");
// define("GOOGLE_CLIENT_SECRET", "EbrWc27MN1MK8fo30UZ2z13N");
if (!defined('GOOGLE_CLIENT_ID')) define('GOOGLE_CLIENT_ID', '509012045176-9hsg971flc78qo7psgaq0h9q18dj4o2e.apps.googleusercontent.com');

if (!defined('GOOGLE_CLIENT_SECRET')) define('GOOGLE_CLIENT_SECRET', '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');

if (!defined('FACEBOOK_CLIENT_ID')) define('FACEBOOK_CLIENT_ID', '886552205696362');


if (!defined('FACEBOOK_CLIENT_SECRET')) define('FACEBOOK_CLIENT_SECRET', '1dc795423fea194a08bd469d4adc190d');

// define("FACEBOOK_CLIENT_ID", "1353188632098960");
// define("FACEBOOK_CLIEN_SECRET","7865e2832e6469dd2b2a0da5189db3ac");