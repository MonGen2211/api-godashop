<?php
require ABSPATH_SITE . 'controller/AddressController.php';
require ABSPATH_SITE . 'controller/AuthController.php';
require ABSPATH_SITE . 'controller/CartController.php';
require ABSPATH_SITE . 'controller/ContactController.php';
require ABSPATH_SITE . 'controller/CustomerController.php';
require ABSPATH_SITE . 'controller/HomeController.php';
require ABSPATH_SITE . 'controller/InformationController.php';
require ABSPATH_SITE . 'controller/PaymentController.php';
require ABSPATH_SITE . 'controller/ProductController.php';
require ABSPATH_SITE . 'controller/ApiProductController.php';
require ABSPATH_SITE . 'controller/ApiCategoryController.php';
require ABSPATH_SITE . 'controller/ApiAuthController.php';
require ABSPATH_SITE . 'controller/ApiCustomerController.php';
require ABSPATH_SITE . 'controller/ApiAddressController.php';
require ABSPATH_SITE . 'controller/ApiPaymentController.php';
require ABSPATH_SITE . 'controller/ApiContactController.php';
