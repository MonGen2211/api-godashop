<?php
echo 'COn gà';
// // router của site (giao diện người dùng)
// session_start();
// // $c = !empty($_GET['c']) ? $_GET['c'] : 'home';
// $c = $_GET['c'] ?? 'home';
// $a = $_GET['a'] ?? 'index';

// // require autoload
// require '../vendor/autoload.php';

// require '../config.php';
// require '../connectDb.php';

// // import bootstrap (model)
// require '../bootstrap.php';

// $str = ucfirst($c) . 'Controller'; //HomeController
// require 'controller/' . $str . '.php'; //controller/HomeController.php
// $controller = new $str(); //new HomeController();
// $controller->$a();//$controller->index();